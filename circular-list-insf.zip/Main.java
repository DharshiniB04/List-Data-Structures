import java.util.*;
public class Main
{
    static class node 
    {
        int data;
        node next;
        node(int d)
        {
            data=d;
            next=null;
        }
    }
    static node head=null;
    static void add(int d)
    {
        node n=new node(d);
        if(head==null)
        {
            head=n;
            n.next=head;
        }
        else{
            node temp=head;
            while(temp.next!=head)
            temp=temp.next;
            n.next=head;
            temp.next=n;
        }
    }
    static void dis()
    {
        node temp=head;
        do{
            System.out.println(temp.data+" ");
            temp=temp.next;
        }while(temp!=head);
    }
    static void insf(int d)
    {
      node n=new node(d);
      n.next=head;
      node temp=head;
      while(temp.next!=head)
      temp=temp.next;
      head=n;
      temp.next=head;
    }
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    while(s.hasNextInt())
	    add(s.nextInt());
		dis();
		insf(89);
		dis();
	}
}
