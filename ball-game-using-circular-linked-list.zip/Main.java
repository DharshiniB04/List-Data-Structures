import java.util.Scanner;

class Player {
    String name;
    Player next;

    public Player(String name) {
        this.name = name;
        this.next = null;
    }
}

class CircularLinkedList {
    Player head;

    public void addPlayer(String name) {
        Player player = new Player(name);
        if (head == null) {
            head = player;
            player.next = head;
        } else {
            Player current = head;
            while (current.next != head) {
                current = current.next;
            }
            current.next = player;
            player.next = head;
        }
    }

    public String getPlayerAtKthPosition(int k) {
        Player current = head;
        for (int i = 1; i < k; i++) {
            current = current.next;
        }
        return current.name;
    }

    public void removePlayerAtKthPosition(int k) {
        Player current = head;
        Player prev = null;
        for (int i = 1; i < k; i++) {
            prev = current;
            current = current.next;
        }
        prev.next = current.next;
        if (current == head) {
            head = current.next;
        }
    }
}

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CircularLinkedList playerList = new CircularLinkedList();

        System.out.print("Enter the number of players: ");
        int numPlayers = scanner.nextInt();
        scanner.nextLine(); 

        for (int i = 1; i <= numPlayers; i++) {
            System.out.print("Enter the name of player " + i + ": ");
            String playerName = scanner.nextLine();
            playerList.addPlayer(playerName);
        }

        System.out.print("Enter the starting player: ");
        String startingPlayer = scanner.nextLine();

        System.out.print("Enter the value of k: ");
        int k = scanner.nextInt();

        
        Player current = playerList.head;
        while (!current.name.equals(startingPlayer)) {
            current = current.next;
        }

        
        String kthPlayer = playerList.getPlayerAtKthPosition(k);
        System.out.println("Player at position " + k + ": " + kthPlayer);
        playerList.removePlayerAtKthPosition(k);

        System.out.println("Next player to pass: " + current.next.name);
    }
}
