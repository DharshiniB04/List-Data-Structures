/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
import java.util.*;
public class Main
{
    static class node{
        int data;
        node next;
    }
    static node head=null;
    static void add(int d){
        node n=new node();
        n.data=d;
        n.next=null;
        if(head==null)
        head=n;
        else{
            node temp=head;
            while(temp.next!=null)
            temp=temp.next;
            temp.next=n;
        }
    }
    static void lead(){
        node temp=head;
        int max=0;
        int m=0;
        while(temp!=null){
        if(temp.data>m || max<temp.data ){
        max=temp.data;}
        m=temp.data;
        temp=temp.next;}
        System.out.println("LEAD : " +max);
        
        
    }
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a = s.nextInt();
		while(a!=0){
		    add(a);
		    a=s.nextInt();
	}
	lead();
}
}
