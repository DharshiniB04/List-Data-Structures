
public class Main
{
    static class node{
        node pre;
        int data;
        node next;
        node (int d){
            data=d;
            pre=null;
            next=null;
        }
    }
    static node head=null;
    static void add(int d){
        node n=new node(d);
        if(head==null)
        head=n;
        else{
            node temp=head;
            while(temp.next!=null)
            temp=temp.next;
            temp.next=n;
            n.pre=temp;
        }
    }
    static void display(){
        node temp=head;
        while(temp!=null){
            System.out.println(temp.data);
            temp=temp.next;
        }
    }
    static void rev(){
        node tem=head;
        while(tem.next!=null){
            tem=tem.next;
        }
        while(tem!=null){
            System.out.println(tem.data);
            tem=tem.pre;
        }
    }
    static void ins(int p,int v)
    {
        node n=new node(v);
        node temp=head;
        while(temp.next!=null)
        {
            if(temp.data==p)
            {
                n.pre=temp;
                n.next=temp.next;
                temp.next.pre=n;
                temp.next=n;
            }
            temp=temp.next;
        }
    }
     static void inspr(int p,int v)
    {
        node n=new node(v);
        node temp=head;
        if(p==head.data)
        {
            temp.pre=n;
            n.next=temp;
            head=n;
        }
        else{
        while(temp.next!=null)
        {
            if(temp.data==p)
            {
                n.next=temp;
                n.pre=temp.pre;
                temp.pre.next=n;
                temp.pre=n;
            }
            temp=temp.next;
        }
        }
    }
	public static void main(String[] args) {
		add(9);
		add(10);
		add(11);

		inspr(10,23);
		display();
	}
}
