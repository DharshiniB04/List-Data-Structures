/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

leader element 
*******************************************************************************/
import java.util.*;
public class Main
{
    static class node{
        int data;
        node next;
    }
    static node head=null;
    static void add(int d){
        node n=new node();
        n.data=d;
        n.next=null;
        if(head==null)
        head=n;
        else{
            node temp=head;
            while(temp.next!=null)
            temp=temp.next;
            temp.next=n;
        }
    }
    static void leader(){
        node temp=head;
        int max=0;
        while(temp!=null){
        if(max<temp.data)
        max=temp.data;
        temp=temp.next;
        }
        System.out.println("Leader Element is "+ max);
    }
	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a = s.nextInt();
		while(a!=0){
		    add(a);
		    a=s.nextInt();
		}
		leader();
	}
}
