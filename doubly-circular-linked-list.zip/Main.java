import java.util.*;
public class Main
{
    static class node 
    {
        int data;
        node pre;
        node next;
        node(int d)
        {
            data=d;
            pre=null;
            next=null;
        }
    }
    static node head=null;
    static void add(int d)
    {
        node n=new node(d);
        if(head==null)
        {
            head=n;
            n.pre=head;
            n.next=head;
        }
        else{
            node temp=head;
            while(temp.next!=head)
            temp=temp.next;
            n.next=head;
            temp.next=n;
            n.pre=temp;
            head.pre=n;
        }
    }
    static void dis()
    {
        node temp=head;
        node prev=null;
        do{
            prev=temp;
            System.out.print(temp.data+" ");
            temp=temp.next;
        }while(temp!=head);
        temp=prev;
        System.out.print("\nbackward\n");
        do{
            System.out.print(prev.data+" ");
            prev=prev.pre;
        }while(prev!=temp);
        
    }
    // static void insf(int d)
    // {
    //   node n=new node(d);
    //   n.next=head;
    //   node temp=head;
    //   while(temp.next!=head)
    //   temp=temp.next;
    //   head=n;
    //   temp.next=head;
    // }
    static void delete(int d){
        node temp=head;
        node prev=null;
       
        while(temp.data!=d){
            prev=temp;
            temp=temp.next;
        } 
        prev.next=temp.next;
        temp.next.pre=prev;
    }
	public static void main(String[] args) {
	    Scanner s=new Scanner(System.in);
	    while(s.hasNextInt())
	    add(s.nextInt());
		//dis();
		//insf(89);
		delete(20);
		dis();
	}
}
