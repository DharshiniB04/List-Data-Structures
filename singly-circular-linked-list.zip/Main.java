/******************************************************************************

                            Online Java Compiler.
                Code, Compile, Run and Debug java program online.
Write your code in this editor and press "Run" button to execute it.

*******************************************************************************/
import java.util.*;
public class Main
{
    static class node{
        int data;
        node next;
    }
    static node head=null;
    static void add(int d){
        node n=new node();
        n.data=d;
        n.next=null;
        if(head==null){
        head=n;
        n.next=head;}
        else{
            node temp=head;
            while(temp.next!=head)
            temp=temp.next;
            n.next=head;
            temp.next=n;
        }
    }
        static void display() {

        node temp = head;
        do {
            System.out.println(temp.data);
            temp = temp.next;
        } while (temp != head);
    }

	public static void main(String[] args) {
		Scanner s=new Scanner(System.in);
		int a = s.nextInt();
		while(a!=0){
		    add(a);
		    a=s.nextInt();
		}
		display();
	}
}
